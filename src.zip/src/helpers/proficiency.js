export const proficiencyArray = [
  {
    label: 'Conversational',
    value: 'conversational'
  },
  {
    label: 'Fluent',
    value: 'fluent'
  },
  {
    label: 'Basic',
    value: 'basic'
  },
  {
    label: 'Native',
    value: 'native'
  }
];
