export const BASE_URL = '/app/dashboard/default';
export const BASE_TITLE = ' | Blue Caller';

export const CONFIG = {
  layout: 'vertical',
  collapseMenu: false,
  layoutType: 'menu-dark'
};
