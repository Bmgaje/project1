export const usersData = [
  {
    id: 1,
    name: 'sam',
    lName: 'karan',
    uName: 'samkaran123',
    status: true
  },
  {
    id: 2,
    name: 'alex',
    lName: 'smith',
    uName: 'alexsmith456',
    status: true
  },
  {
    id: 3,
    name: 'jane',
    lName: 'doe',
    uName: 'janedoe789',
    status: false
  },
  {
    id: 4,
    name: 'john',
    lName: 'doe',
    uName: 'johndoe101',
    status: true
  },
  {
    id: 5,
    name: 'emma',
    lName: 'brown',
    uName: 'emmabrown112',
    status: false
  },
  {
    id: 6,
    name: 'liam',
    lName: 'johnson',
    uName: 'liamjohnson131',
    status: true
  },
  {
    id: 7,
    name: 'olivia',
    lName: 'williams',
    uName: 'oliviawilliams141',
    status: false
  },
  {
    id: 8,
    name: 'noah',
    lName: 'jones',
    uName: 'noahjones151',
    status: true
  },
  {
    id: 9,
    name: 'sophia',
    lName: 'garcia',
    uName: 'sophiagarcia161',
    status: true
  },
  {
    id: 10,
    name: 'william',
    lName: 'martinez',
    uName: 'williammartinez171',
    status: false
  },
  {
    id: 11,
    name: 'mia',
    lName: 'rodriguez',
    uName: 'miarodriguez181',
    status: true
  }
];
