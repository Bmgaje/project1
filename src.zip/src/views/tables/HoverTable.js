import React from 'react';

function HoverTable() {
  return <div>HoverTable</div>;
}

export default HoverTable;
